package com.smart.smartmart;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.text.InputType;
import android.graphics.drawable.GradientDrawable;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final String ADMIN_UID = "yiBQHogdDAcloQ5TktRDusa0VH72";
    private static final String DB_URL = "https://smart-mart-fb3f2-default-rtdb.firebaseio.com/";
    private FirebaseAuth auth;
    private DatabaseReference db;
    private LinearLayout page;
    private EditText identity, pass;
    private boolean registerMode = false;
    private boolean firebaseReady = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(7, 91, 53));
        getWindow().setNavigationBarColor(Color.rgb(7, 91, 53));
        showStartupScreen(); // UI is rendered before Firebase setup, preventing a blank/black screen.
        try {
            FirebaseApp app = FirebaseApp.initializeApp(getApplicationContext());
            if (app == null) throw new IllegalStateException("Firebase config পাওয়া যায়নি");
            auth = FirebaseAuth.getInstance(app);
            db = FirebaseDatabase.getInstance(app, DB_URL).getReference();
            firebaseReady = true;
            if (auth.getCurrentUser() != null) showHome();
            else showLogin();
        } catch (Exception ex) {
            showFirebaseError(ex.getMessage());
        }
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable rounded(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(14)); return d;
    }
    private TextView label(String value, int size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(dp(6), dp(9), dp(6), dp(9));
        return t;
    }
    private Button action(String title, Runnable callback) {
        Button b = new Button(this);
        b.setText(title); b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackground(rounded(Color.rgb(7, 91, 53)));
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        b.setOnClickListener(v -> callback.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.setMargins(0, dp(7), 0, dp(7)); b.setLayoutParams(lp);
        return b;
    }
    private EditText input(String hint, boolean secret) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setHint(hint); e.setTextColor(Color.BLACK);
        e.setHintTextColor(Color.GRAY); e.setPadding(dp(14), dp(8), dp(14), dp(8));
        e.setBackground(rounded(Color.WHITE));
        if (secret) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.setMargins(0, dp(7), 0, dp(7)); e.setLayoutParams(lp);
        return e;
    }
    private void makePage(String heading) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        outer.setPadding(dp(20), dp(26), dp(20), dp(24));
        outer.setBackgroundColor(Color.rgb(242, 248, 243));
        TextView title = label(heading, 27, true, Color.rgb(7, 91, 53));
        title.setGravity(Gravity.CENTER);
        outer.addView(title, new LinearLayout.LayoutParams(-1, -2));
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(16), dp(14), dp(16));
        page.setBackground(rounded(Color.rgb(231, 241, 233)));
        LinearLayout.LayoutParams card = new LinearLayout.LayoutParams(-1, -2);
        card.setMargins(0, dp(16), 0, 0);
        outer.addView(page, card);
        scroll.addView(outer);
        setContentView(scroll);
    }
    private void showStartupScreen() {
        makePage("SMART MART");
        page.addView(label("অ্যাপ চালু হচ্ছে…", 17, true, Color.DKGRAY));
    }
    private void showFirebaseError(String message) {
        makePage("SMART MART");
        page.addView(label("Firebase সংযোগ প্রস্তুত হয়নি", 19, true, Color.RED));
        page.addView(label(message == null ? "google-services.json এবং Firebase সেটিংস পরীক্ষা করুন।" : message, 14, false, Color.DKGRAY));
        page.addView(label("স্ক্রিন কালো থাকবে না। Firebase কনফিগারেশন ঠিক হলে আবার অ্যাপ চালু করুন।", 14, false, Color.DKGRAY));
    }
    private void showLogin() {
        makePage("SMART MART");
        page.addView(label("আপনার অ্যাকাউন্টে প্রবেশ করুন", 17, true, Color.DKGRAY));
        identity = input("Firebase ইমেইল", false);
        pass = input("পাসওয়ার্ড", true);
        page.addView(identity); page.addView(pass);
        page.addView(action(registerMode ? "কাস্টমার অ্যাকাউন্ট তৈরি করুন" : "লগইন", () -> authenticate()));
        page.addView(action(registerMode ? "আগে অ্যাকাউন্ট আছে? লগইন" : "নতুন কাস্টমার অ্যাকাউন্ট", () -> {
            registerMode = !registerMode; showLogin();
        }));
        page.addView(label("অ্যাডমিন: Firebase Authentication-এ থাকা ইমেইল ও পাসওয়ার্ড ব্যবহার করুন।", 13, false, Color.DKGRAY));
        page.addView(label("কাস্টমার: Email/Password provider চালু থাকতে হবে।", 13, false, Color.DKGRAY));
    }
    private void authenticate() {
        String email = identity.getText().toString().trim();
        String password = pass.getText().toString();
        if (email.isEmpty() || password.length() < 6) { toast("সঠিক ইমেইল ও কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন"); return; }
        if (registerMode) {
            auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this, task -> {
                if (!task.isSuccessful()) { toast("অ্যাকাউন্ট তৈরি হয়নি: " + task.getException().getMessage()); return; }
                FirebaseUser u = auth.getCurrentUser();
                Map<String,Object> data = new HashMap<>();
                data.put("email", email); data.put("role", "customer");
                db.child("users").child(u.getUid()).setValue(data)
                    .addOnSuccessListener(x -> showHome())
                    .addOnFailureListener(e -> toast("প্রোফাইল সংরক্ষণ হয়নি: " + e.getMessage()));
            });
        } else {
            auth.signInWithEmailAndPassword(email, password).addOnCompleteListener(this, task -> {
                if (task.isSuccessful()) showHome();
                else toast("লগইন ব্যর্থ: " + task.getException().getMessage());
            });
        }
    }
    private void showHome() {
        FirebaseUser u = auth.getCurrentUser();
        if (u == null) { showLogin(); return; }
        boolean admin = ADMIN_UID.equals(u.getUid());
        makePage(admin ? "SMART MART • ADMIN" : "SMART MART");
        page.addView(label(admin ? "স্বাগতম, অ্যাডমিন" : "স্বাগতম, কাস্টমার", 18, true, Color.DKGRAY));
        page.addView(action("পণ্য দেখুন", () -> showProducts()));
        if (admin) {
            page.addView(label("নতুন পণ্য যোগ করুন", 17, true, Color.DKGRAY));
            EditText name = input("পণ্যের নাম", false);
            EditText price = input("দাম (টাকা)", false);
            EditText category = input("ক্যাটাগরি", false);
            page.addView(name); page.addView(price); page.addView(category);
            page.addView(action("পণ্য সংরক্ষণ", () -> {
                String n=name.getText().toString().trim(), p=price.getText().toString().trim(), c=category.getText().toString().trim();
                if(n.isEmpty() || p.isEmpty()) { toast("পণ্যের নাম ও দাম লিখুন"); return; }
                String id=db.child("products").push().getKey();
                Map<String,Object> item=new HashMap<>();
                item.put("name",n); item.put("price",p); item.put("category",c); item.put("available",true);
                db.child("products").child(id).setValue(item)
                    .addOnSuccessListener(x -> toast("পণ্য যোগ হয়েছে"))
                    .addOnFailureListener(e -> toast("সংরক্ষণ ব্যর্থ: "+e.getMessage()));
            }));
            page.addView(action("অর্ডার দেখুন", () -> showOrders()));
        }
        page.addView(action("লগআউট", () -> { auth.signOut(); showLogin(); }));
    }
    private void showProducts() {
        makePage("পণ্যের তালিকা");
        page.addView(action("ফিরে যান", () -> showHome()));
        db.child("products").addListenerForSingleValueEvent(new ValueEventListener() {
            public void onDataChange(DataSnapshot snapshot) {
                if (!snapshot.exists()) page.addView(label("এখনো কোনো পণ্য নেই।", 15, false, Color.DKGRAY));
                for (DataSnapshot p : snapshot.getChildren()) {
                    page.addView(label(String.valueOf(p.child("name").getValue()) + " — ৳" +
                        String.valueOf(p.child("price").getValue()), 16, true, Color.DKGRAY));
                }
            }
            public void onCancelled(DatabaseError error) { toast("পণ্য লোড হয়নি: " + error.getMessage()); }
        });
    }
    private void showOrders() {
        makePage("অর্ডার তালিকা");
        page.addView(action("ফিরে যান", () -> showHome()));
        db.child("orders").addListenerForSingleValueEvent(new ValueEventListener() {
            public void onDataChange(DataSnapshot snapshot) {
                if (!snapshot.exists()) page.addView(label("এখনো কোনো অর্ডার নেই।", 15, false, Color.DKGRAY));
                for (DataSnapshot order : snapshot.getChildren())
                    page.addView(label("অর্ডার: " + order.getKey(), 14, false, Color.DKGRAY));
            }
            public void onCancelled(DatabaseError error) { toast("অর্ডার লোড হয়নি: " + error.getMessage()); }
        });
    }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
}
