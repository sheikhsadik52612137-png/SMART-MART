SMART MART Android Project — Black Screen Fix (v1.1)

এই সংস্করণে:
- Firebase চালুর আগেই দৃশ্যমান UI দেখায়; Firebase ব্যর্থ হলেও কালো স্ক্রিন না দেখিয়ে error দেখায়।
- Firebase initializeApp(context) থেকে পাওয়া FirebaseApp ব্যবহার করে Auth এবং Realtime Database শুরু হয়।
- লগইন ফর্মে Firebase Authentication-এর ইমেইল ও পাসওয়ার্ড ব্যবহার করতে হবে।
- Admin UID: yiBQHogdDAcloQ5TktRDusa0VH72

গুরুত্বপূর্ণ:
- এটি Android Studio source project, APK নয়।
- আপনার Firebase-এ নিবন্ধিত package name 'Com.smart.smartmart' অপরিবর্তিত।
- Android Studio-তে JDK 17, Android SDK Platform 35 প্রয়োজন।
- Build > Build Bundle(s)/APK(s) > Build APK(s) দিয়ে APK তৈরি করুন।
- যদি পুরনো APK ফোনে ইনস্টল থাকে, নতুন APK ইনস্টল করার আগে পুরনোটি uninstall করতে হতে পারে (ডেটা হারানোর ঝুঁকি আছে); সম্ভব হলে একই signing key দিয়ে update করুন।
- Customer account-এর জন্য Firebase Email/Password ব্যবহৃত হচ্ছে; phone OTP নেই।
- এটি প্রাথমিক সংস্করণ; cart, checkout, payment gateway, image upload, order creation এবং production security hardening এখনও বাকি।
